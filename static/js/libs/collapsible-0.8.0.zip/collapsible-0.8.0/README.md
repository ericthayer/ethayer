# collapsible

[![Filament Group](http://filamentgroup.com/images/fg-logo-positive-sm-crop.png) ](http://www.filamentgroup.com/)

## [Demos](http://master.origin.collapsible.fgview.com/demo/index.html)

- OR if you want to preview a specific branch: http://BRANCHNAMEHERE.origin.collapsible.fgview.com/demos/

[![Build Status](https://travis-ci.org/filamentgroup/dialog.svg)](https://travis-ci.org/filamentgroup/dialog)
